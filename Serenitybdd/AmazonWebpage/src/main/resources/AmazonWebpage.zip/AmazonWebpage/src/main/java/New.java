import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class New {

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver",
                "C:\\Users\\arjunshekar_g\\Downloads\\chromedriver_win32\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.amazon.in/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//*[@id=\"nav-link-accountList-nav-line-1\"]")).click();
        driver.findElement(By.id("createAccountSubmit")).click();
        driver.findElement(By.id("ab-registration-link")).click();
        driver.findElement(By.className("b-form-control")).sendKeys("arjunshekar@hcl.com");

        driver.findElement(By.id("submitEmailButtonId")).click();

        driver.findElement(By.id("ap_customer_name")).sendKeys("Arjun");
        driver.findElement(By.id("ap_password")).sendKeys("Hcl@2001");
        driver.findElement(By.id("ap_password_check")).sendKeys("Hcl@2001");
        driver.findElement(By.id("continue")).click();

    }
}



